# Deploy on Vercel (step by step)

Vercel cannot keep files or SQLite databases, so this version uses:
- **Postgres** (free Neon database) for all data
- **Vercel Blob** for uploaded photos/documents
- a signed cookie for login sessions

## 1. Upload the project to GitHub
Create a new GitHub repository and upload the contents of this folder (do NOT upload `node_modules` or `.env`).

## 2. Create the database (Neon, free)
Vercel dashboard -> your project -> **Storage** -> **Create Database** -> **Neon (Postgres)**. Connect it to the project.
This adds `DATABASE_URL` automatically. (Tables are created automatically on the first request.)

## 3. Create the file storage
Same **Storage** tab -> **Create** -> **Blob** -> connect to the project.
This adds `BLOB_READ_WRITE_TOKEN` automatically.

## 4. Add the session secret
Settings -> **Environment Variables** -> add `SESSION_SECRET` = any long random text (40+ characters). Apply to Production, Preview and Development.

## 5. Deploy
Import the GitHub repo in Vercel. Framework preset: **Other**. Leave Build/Output settings empty (vercel.json handles it). Click **Deploy**.
If you added the storage/env vars AFTER the first deploy, click **Redeploy**.

## 6. Create the first admin (one time, on your computer)
In Vercel -> Storage -> your Neon database -> copy the `DATABASE_URL` connection string.
```bash
npm install
DATABASE_URL="paste-the-url-here" npm run create-admin
```
(Windows PowerShell: `$env:DATABASE_URL="paste-the-url-here"; npm run create-admin`)
Then open `https://your-site.vercel.app/login.html` and log in.

## Limits to know
- Each uploaded file must be small: admission photo/document up to 2 MB each; admin photos are resized automatically in the browser and uploaded one at a time.
- Old data from the local SQLite files (`school.db`, `content.db`) is NOT moved automatically; start fresh on Vercel.

---
# Running on Replit instead
1. Create a Repl (Node.js) and upload this folder's contents (Import from GitHub or upload the zip and extract).
2. Tools -> **Secrets**: add `DATABASE_URL` (free Neon Postgres connection string) and `SESSION_SECRET` (long random text).
3. Shell tab: `npm install` then `npm run create-admin` (one time, creates the first admin).
4. Press **Run**. Open the web preview, then go to `/login.html`.
Note: on Replit, uploaded photos are saved in `public/uploads`. On Autoscale deployments they can disappear after a restart; use a Reserved VM deployment to keep them.
